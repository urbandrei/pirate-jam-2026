// Game server URL configuration
// Update this URL before uploading to itch.io to point to your deployed server
// Example: 'https://your-app.railway.app' or 'https://your-app.onrender.com'
window.GAME_SERVER_URL = 'https://pirate-jam-2026.onrender.com';
